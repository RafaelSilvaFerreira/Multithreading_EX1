package Multithreading;

public class ThreadVetor extends Thread{
	private int valor;
	private int[] vetor;
	private String name;
	
public ThreadVetor (int valor, int vetor[]){
	this.name  = (String) ("Thread "+ valor);
	this.valor = valor;
	this.vetor = vetor;

}

public void run(){
	System.out.println("Iniciando thread "+
	this.valor+
	"...");
	
	long inic  = System.nanoTime();
	
	if (valor%2==0){ 
		for (int i=0; i<=vetor.length; i++){
			
		}
	}
	else
	{
		for (int i: vetor){
			
	}
	
	long fim = System.nanoTime()-inic;
	System.out.println("Thread finalizada em "+
	fim + // pq tá dando 0????
	" segundos"
	);
	}
}
}
