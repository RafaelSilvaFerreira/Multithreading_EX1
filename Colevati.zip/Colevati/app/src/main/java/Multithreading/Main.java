package Multithreading;

import java.util.Random;


public class Main {


public static void main (String [] args){
	Random alea = new Random();
	
	int[] vetor = new int[1000];
	
	for (int i=0; i<1000; i++){
		vetor[i]= alea.nextInt(99)+1;
	}
	ThreadVetor thread1= new ThreadVetor(1,vetor);
	ThreadVetor thread2= new ThreadVetor(2,vetor);
	
	thread1.run();
	thread2.run();
}

}
